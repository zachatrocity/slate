var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => Slate
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");
var mime = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp" };
function b64(a) {
  const bytes = new Uint8Array(a);
  let str = "";
  for (let i = 0; i < bytes.length; i += 8192) str += String.fromCharCode(...bytes.subarray(i, i + 8192));
  return btoa(str);
}
var Slate = class extends import_obsidian.Plugin {
  constructor() {
    super(...arguments);
    __publicField(this, "settings", { url: "", token: "", theme: "slate" });
    __publicField(this, "busy", false);
  }
  async onload() {
    Object.assign(this.settings, await this.loadData());
    this.addSettingTab(new SettingsTab(this));
    this.addCommand({ id: "publish", name: "Publish slides", callback: () => this.publish() });
    this.addRibbonIcon("presentation", "Publish slides", () => this.publish());
    this.addCommand({ id: "open", name: "Open published slideshow", callback: () => {
      const f = this.app.workspace.getActiveFile();
      const u = f && this.app.metadataCache.getFileCache(f)?.frontmatter?.slides_url;
      if (typeof u === "string" && /^https?:\/\//.test(u)) window.open(u, "_blank");
      else new import_obsidian.Notice("Publish this note first.");
    } });
  }
  async publish() {
    if (this.busy) return;
    const file = this.app.workspace.getActiveFile();
    if (!file || file.extension !== "md") {
      new import_obsidian.Notice("Open a Markdown note first.");
      return;
    }
    if (!/^https?:\/\//.test(this.settings.url)) {
      new import_obsidian.Notice("Set your server URL in Slate settings first.");
      return;
    }
    if (!this.settings.token) {
      new import_obsidian.Notice("Set your publishing token in Slate settings first.");
      return;
    }
    this.busy = true;
    const notice = new import_obsidian.Notice("Preparing slides\u2026", 0);
    try {
      let markdown = await this.app.vault.read(file);
      const fm = this.app.metadataCache.getFileCache(file)?.frontmatter || {};
      let id = fm.slide_id;
      if (!id) {
        id = globalThis.crypto?.randomUUID?.() || "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
          const v = Math.floor(Math.random() * 16);
          return (c === "x" ? v : v & 3 | 8).toString(16);
        });
        await this.app.fileManager.processFrontMatter(file, (f) => {
          f.slide_id = id;
        });
      }
      const assets = [];
      const names = /* @__PURE__ */ new Map();
      let total = 0;
      const image = async (link) => {
        if (/^data:image\//.test(link)) return link;
        if (/^[a-z]+:|^\/\//i.test(link)) throw Error("Save remote images in your vault before publishing.");
        let target = decodeURIComponent(link.split("#")[0]);
        const f = this.app.metadataCache.getFirstLinkpathDest(target, file.path) || this.app.vault.getAbstractFileByPath((0, import_obsidian.normalizePath)(file.parent.path + "/" + target));
        if (!(f instanceof import_obsidian.TFile) || !mime[f.extension.toLowerCase()]) throw Error("Unsupported or missing image: " + link + " (use PNG, JPEG, WebP or GIF)");
        if (names.has(f.path)) return "assets/" + names.get(f.path);
        const data = await this.app.vault.readBinary(f);
        total += data.byteLength;
        if (data.byteLength > 15 * 1024 * 1024 || total > 40 * 1024 * 1024) throw Error("Images exceed 15 MB each / 40 MB total.");
        const name = "image-" + assets.length + "." + f.extension.toLowerCase();
        assets.push({ name, mime: mime[f.extension.toLowerCase()], base64: b64(data) });
        names.set(f.path, name);
        return "assets/" + name;
      };
      const pieces = markdown.split(/(```[\s\S]*?```|~~~[\s\S]*?~~~|`[^`\n]*`)/g);
      for (let p = 0; p < pieces.length; p += 2) {
        let s = pieces[p];
        const wiki = [...s.matchAll(/!\[\[([^\]]+)\]\]/g)];
        for (const m of wiki) {
          const [link, caption = ""] = m[1].split("|");
          const url = await image(link);
          s = s.replace(m[0], `![${/^\d+(x\d+)?$/.test(caption) ? "width:" + caption.split("x")[0] : caption}](${url})`);
        }
        const imgs = [...s.matchAll(/!\[([^\]]*)\]\((<[^>]+>|[^\s)]+)(?:\s+"[^"]*")?\)/g)];
        for (const m of imgs) {
          const link = m[2].replace(/^<|>$/g, "");
          if (link.startsWith("assets/") && assets.some((a) => "assets/" + a.name === link)) continue;
          const url = await image(link);
          s = s.replace(m[0], `![${m[1]}](${url})`);
        }
        if (/!\[[^\]]*\]\[/.test(s)) throw Error("Use inline image links rather than reference-style images.");
        pieces[p] = s;
      }
      markdown = pieces.join("");
      notice.setMessage("Rendering slides and PDF\u2026");
      const response = await (0, import_obsidian.requestUrl)({ url: this.settings.url.replace(/\/$/, "") + "/api/decks", method: "POST", headers: { Authorization: "Bearer " + this.settings.token, "Content-Type": "application/json" }, body: JSON.stringify({ id, title: file.basename, markdown, theme: fm.slide_theme || fm.theme || this.settings.theme, assets }), throw: false });
      if (response.status !== 200) throw Error(response.json?.error || "Publishing failed: " + response.status);
      const result = response.json;
      if (!result.id || !/^https?:\/\//.test(result.url) || !/^https?:\/\//.test(result.pdfUrl)) throw Error("Invalid server response");
      await this.app.fileManager.processFrontMatter(file, (f) => {
        f.slide_id = result.id;
        f.slides_url = result.url;
        f.slides_pdf = result.pdfUrl;
        f.slide_theme = result.theme || fm.slide_theme || this.settings.theme;
      });
      new import_obsidian.Notice("Published " + result.slides + " slides. Links added to note properties.");
    } catch (e) {
      new import_obsidian.Notice("Slate: " + e.message, 12e3);
    } finally {
      notice.hide();
      this.busy = false;
    }
  }
};
var SettingsTab = class extends import_obsidian.PluginSettingTab {
  constructor(p) {
    super(p.app, p);
    __publicField(this, "p");
    this.p = p;
  }
  display() {
    const c = this.containerEl;
    c.empty();
    c.createEl("h2", { text: "Slate" });
    c.createEl("p", { text: "Publish from desktop or mobile to your Slate server." });
    new import_obsidian.Setting(c).setName("Server URL").addText((t) => t.setPlaceholder("https://slides.example.com").setValue(this.p.settings.url).onChange(async (v) => {
      this.p.settings.url = v;
      await this.p.saveData(this.p.settings);
    }));
    new import_obsidian.Setting(c).setName("Publishing token").setDesc("Saved in this plugin\u2019s data.json, not in note frontmatter. Treat plugin settings as private.").addText((t) => {
      t.inputEl.type = "password";
      t.setValue(this.p.settings.token).onChange(async (v) => {
        this.p.settings.token = v;
        await this.p.saveData(this.p.settings);
      });
    });
    new import_obsidian.Setting(c).setName("Default theme").setDesc("Use slide_theme in a note to override. Built-ins: default, gaia, uncover; Slate: slate; community: graph_paper.").addText((t) => t.setValue(this.p.settings.theme).onChange(async (v) => {
      this.p.settings.theme = v;
      await this.p.saveData(this.p.settings);
    }));
  }
};
